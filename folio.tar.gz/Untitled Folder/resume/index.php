<div class="container">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link href="style.css" rel="stylesheet">
<div class="resume">
    <header class="page-header">
    <h1 class="page-title">Brijesh Yadav</h1>
    <small> <i class="fa fa-clock-o"></i> Last Updated on: <time>Sunday, November 05, 2017</time></small>
  </header>
<div class="row">
  <div class="col-xs-12 col-sm-12 col-md-offset-1 col-md-10 col-lg-offset-2 col-lg-8">
    <div class="panel panel-default">
      <div class="panel-heading resume-heading">
        <div class="row">
          <div class="col-lg-12">
            <div class="col-xs-12 col-sm-4">
              <figure>
                <img class="img-circle img-responsive" alt="" src="http://placehold.it/300x300">
              </figure>
              
              <div class="row">
                <div class="col-xs-12 social-btns">
                  
                    <!-- <div class="col-xs-3 col-md-1 col-lg-1 social-btn-holder">
                      <a href="#" class="btn btn-social btn-block btn-google">
                        <i class="fa fa-google"></i> </a>
                    </div> -->
                  
                    <!-- <div class="col-xs-3 col-md-1 col-lg-1 social-btn-holder">
                      <a href="#" class="btn btn-social btn-block btn-facebook">
                        <i class="fa fa-facebook"></i> </a>
                    </div> -->
                  
                    <!-- <div class="col-xs-3 col-md-1 col-lg-1 social-btn-holder">
                      <a href="#" class="btn btn-social btn-block btn-twitter">
                        <i class="fa fa-twitter"></i> </a>
                    </div> -->
                    
                    <div class="col-xs-3 col-md-1 col-lg-1 social-btn-holder">
                    </div>


                    <div class="col-xs-3 col-md-1 col-lg-1 social-btn-holder">
                      <a href="https://www.linkedin.com/in/brijesh-yadav-a35117108" target="_blank" class="btn btn-social btn-block btn-linkedin">
                        <i class="fa fa-linkedin"></i> </a>
                    </div>
                  
                    <div class="col-xs-3 col-md-1 col-lg-1 social-btn-holder">
                      <a href="http://www.github.com/brijeshyadav15" target="_blank" class="btn btn-social btn-block btn-github">
                        <i class="fa fa-github"></i> </a>
                    </div>
                  
                    <div class="col-xs-3 col-md-1 col-lg-1 social-btn-holder">
                      <a href="https://stackoverflow.com/users/7734961/brijesh-yadav" target="_blank" class="btn btn-social btn-block btn-stackoverflow">
                        <i class="fa fa-stack-overflow"></i> </a>
                    </div>
                  
                </div>
              </div>
              
            </div>

            <div class="col-xs-12 col-sm-8">
              <ul class="list-group">
                <li class="list-group-item">Brijesh Yadav</li>
                <li class="list-group-item"><i class="fa fa-code"></i> Web Developer</li>
                <li class="list-group-item"><i class="fa fa-briefcase"></i> Ncrypted Technologies Pvt Ltd. </li>
                <li class="list-group-item"><i class="fa fa-link"></i><a href="http://brijeshyadav.ml/"> brijeshyadav.ml</a> </li>
                <li class="list-group-item"><i class="fa fa-phone"></i>  +91 8734819338 </li>
                <li class="list-group-item"><i class="fa fa-envelope"></i><a href="mailto:brijeshyadav152@gmail.com"> brijeshyadav152@gmail.com</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="bs-callout bs-callout-danger">
        <h4>Summary</h4>
        <p>
         Lorem ipsum dolor sit amet, ea vel prima adhuc, scripta liberavisse ea quo, te vel vidit mollis complectitur. Quis verear mel ne. Munere vituperata vis cu, 
         te pri duis timeam scaevola, nam postea diceret ne. Cum ex quod aliquip mediocritatem, mei habemus persecuti mediocritatem ei.
        </p>
        <p>
            Odio recteque expetenda eum ea, cu atqui maiestatis cum. Te eum nibh laoreet, case nostrud nusquam an vis. 
            Clita debitis apeirian et sit, integre iudicabit elaboraret duo ex. Nihil causae adipisci id eos.

        </p>
      </div>
      <div class="bs-callout bs-callout-danger">
        <h4>Research Interests</h4>
        <p>
          Software Engineering, Web Development ,Machine Learning, Image Processing,
          Computer Vision, Artificial Neural Networks, Data Science, Big Data, Evolutionary Algorithms.
        </p>
      </div>

      <div class="bs-callout bs-callout-danger">
        <h4>Prior Experiences</h4>
        <ul class="list-group">
          <a class="list-group-item inactive-link" href="#">
            <h4 class="list-group-item-heading">
              Web Developer at Ncrypted Technologies Pvt. Ltd
            </h4>
            <p class="list-group-item-text" style="text-align: justify">
              Currently, Working as Web Developer at Ncrypted Technologies Pvt. Ltd from Jan-2017. My main responsibilities here include developing and maintaining websites according to Client's requirements. I work here on LAMP architecture as also with Javascript and API's. 
            </p>
          </a>
        </ul>
      </div>

      <div class="bs-callout bs-callout-danger">
        <h4>Projects</h4>
        <ul class="list-group">
          <a class="list-group-item inactive-link" href="#">
            <h4 class="list-group-item-heading">
              Stock Value Predictor
            </h4>
            <p class="list-group-item-text" style="text-align: justify">
              SVP is a prediction based web app which calculate and predict the possible change in stock of a particular share. It uses ANN , SVM for predicting the changes and it is developed in Python and PHP with the help of Pandas, Numpy and SciPy libraries. 
            </p>
          </a>
        </ul>
        <ul class="list-group">
          <a class="list-group-item inactive-link" href="#">
            <h4 class="list-group-item-heading">
              Virtual Mouse
            </h4>
            <p class="list-group-item-text" style="text-align: justify">
              Virtual Mouse is a Desktop which helps to access our mouse from a distant with help of Webcam.It was developed in Java with OpenCV and JavaCV.
            </p>
          </a>
        </ul>
        <ul class="list-group">
          <a class="list-group-item inactive-link" href="#">
            <h4 class="list-group-item-heading">
              IP-PBX
            </h4>
            <p class="list-group-item-text" style="text-align: justify">
              Description of IP-PBX. 
            </p>
          </a>
        </ul>
      </div>
      <div class="bs-callout bs-callout-danger">
        <h4>Key Expertise</h4>
        <ul class="list-group">
          <li class="list-group-item"> Web Development</li>
          <li class="list-group-item"> Machine Learning / Artificial Learning</li>
          <li class="list-group-item">UI/UX</li>
          <li class="list-group-item"> Data Scrapping / Data Mining</li>
          <li class="list-group-item"> API Integration</li>
          <li class="list-group-item">Algorithms</li>
          <!-- <li class="list-group-item"> Lorem ipsum dolor sit amet, ea vel prima adhuc</li> -->
        </ul>
      </div>
      <div class="bs-callout bs-callout-danger">
        <h4>Language and Platform Skills</h4>
        <ul class="list-group">
          <a class="list-group-item inactive-link" href="#">
            

            <!-- <div class="progress">
              <div data-placement="top" style="width: 80%;" 
              aria-valuemax="100" aria-valuemin="0" aria-valuenow="80" role="progressbar" class="progress-bar progress-bar-success">
                <span class="sr-only">80%</span>
                <span class="progress-type">Java/ JavaEE/ Spring Framework </span>
              </div>
            </div> -->
            <div class="progress">
              <div data-placement="top" style="width: 70%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="1" role="progressbar" class="progress-bar progress-bar-success">
                <span class="sr-only">70%</span>
                <span class="progress-type">PHP/ Lamp Stack</span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 50%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="50" role="progressbar" class="progress-bar progress-bar-warning">
                <span class="sr-only">50%</span>
                <span class="progress-type">Machine Learning / Artificial Intelligence</span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 65%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="1" role="progressbar" class="progress-bar progress-bar-success">
                <span class="sr-only">65%</span>
                <span class="progress-type">Python/ Numpy/ Scipy</span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 35%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="1" role="progressbar" class="progress-bar progress-bar-warning">
                <span class="sr-only">35%</span>
                <span class="progress-type">Scikit Learn/Tensorflow/ Pandas</span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 50%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="60" role="progressbar" class="progress-bar progress-bar-warning">
                <span class="sr-only">50%</span>
                <span class="progress-type">C</span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 50%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="50" role="progressbar" class="progress-bar progress-bar-warning">
                <span class="sr-only">50%</span>
                <span class="progress-type">C++</span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 20%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="50" role="progressbar" class="progress-bar progress-bar-danger">
                <span class="sr-only">20%</span>
                <span class="progress-type">Angular JS/ NodeJS</span>
              </div>
            </div>
            <div class="progress-meter">
              <div style="width: 25%;" class="meter meter-left"><span class="meter-text">I know basics</span></div>
              <div style="width: 25%;" class="meter meter-left"><span class="meter-text">I know little</span></div>
              <div style="width: 30%;" class="meter meter-right"><span class="meter-text">I'm a guru</span></div>
              <div style="width: 20%;" class="meter meter-right"><span class="meter-text">I''m good</span></div>
            </div>

          </a>

        </ul>
      </div>
      <div class="bs-callout bs-callout-danger">
        <h4>Education</h4>
        <table class="table table-striped table-responsive ">
          <thead>
            <tr><th>Degree</th>
            <th>Graduation Year</th>
            <th>CGPA</th>
          </tr></thead>
          <tbody>
            <tr>
              <td>Bachelors in Information Technology , LJIET</td>
              <td>2017</td>
              <td> 8.73 </td>
            </tr>
            <tr>
              <td>Diploma in Information Technology, GPA</td>
              <td>2014</td>
              <td>7.96</td>
            </tr>
            <tr>
              <td>SSC, Sadhu Vaswani </td>
              <td>2011</td>
              <td>86.4%</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="bs-callout bs-callout-danger">
        <h4>Training/Workshop</h4>
        <table class="table table-striped table-responsive ">
          <thead>
            <tr><th>Name</th>
            <th>Institute</th>
            <th>Duration</th>
            <th>Year</th>
            </tr></thead>
          <tbody>
            <tr>
              <td>Web Development Workshop</td>
              <td>LJIET/ Backbenchers Developers</td>
              <td>15 days</td>
              <td> June , 2015</td>
            </tr>
            <tr>
              <td>Java and Algorithms</td>
              <td>LJMCA</td>
              <td>15</td>
              <td> Jan, 2016</td>
            </tr>
          </tbody>
        </table>
      </div>

    <div class="bs-callout bs-callout-danger">
        <h4>Certification /MOOCs</h4>
        <table class="table table-striped table-responsive ">
          <thead>
            <tr><th>Name</th>
            <th>Institute</th>
            <th>Status</th>
            </tr></thead>
          <tbody>
            <tr>
              <td>Introduction to Cloud Computing</td>
              <td>IEEE</td>
              <td> Completed </td>
            </tr>
            <tr>
              <td>Intro to Python for Data Science </td>
              <td>Datacamp</td>
              <td>Completed</td>
            </tr>
            <tr>
              <td>Intro to SQL for Data Science </td>
              <td>Datacamp</td>
              <td>Completed</td>
            </tr>
            <tr>
              <td>Introductory course for Machine Learning by Udacity</td>
              <td>Udacity</td>
              <td>Completed</td>
            </tr>
            <tr>
              <td>Machine Learning</td>
              <td>Coursera</td>
              <td>Running</td>
            </tr>
            <tr>
              <td>Deep Learning Specialization</td>
              <td>deeplearning.ai / Coursera</td>
              <td>Running</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</div>
    
</div>

</div>