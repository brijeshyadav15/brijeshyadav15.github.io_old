<?php
require_once "class.phpmailer.php";

$conn = mysqli_connect("localhost","id3370765_brijesh_yadav","brijesh@15","id3370765_portfolio_data");
extract($_POST);
$insert = "Insert into contact_table(name,email,contact_no,message,date,ip,location) Values('".$name."','".$email."','".$contactno."','".$message."','".date('Y-m-d H:i:s')."','".$ip."','".$location."')";
$qrysel =mysqli_query($conn,$insert);


	$from_nm = 'Brijesh Yadav';
	$from_email = 'brijeshyadav152@gmail.com';

	$headers = "Reply-To: Brijesh Yadav <admin@brijeshyadav.ml>\r\n";
	$headers .= "From: Brijesh Yadav <admin@brijeshyadav.ml>\r\n";
	$headers .= "Return-Path: Brijesh Yadav <admin@brijeshyadav.ml>\r\n";
	$headers .= "Organization: Brijesh Yadav\r\n";
	$headers .= "X-Priority: 3\r\n";
	$headers .= "X-Mailer: PHP" . phpversion() . "\r\n";
	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Transfer-Encoding: 8bit\r\n";
	$headers .= "Content-type: text/html; charset=UTF-8\r\n";
	
	$mail = new PHPMailer(); // create a new object
	$mail->IsSMTP(); // enable SMTP
	$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
	$mail->SMTPAuth = true; // authentication enabled
	//mail via gmail
	$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 465; // or 587

    $mailbody = '<table bgcolor="#ececec" border="0" cellpadding="0" cellspacing="0" style="margin:0 auto 0;" width="90%">
	                <tbody><tr><td><table bgcolor="#b62c29" border="0" cellpadding="0" cellspacing="0" style="padding:10px;" width="100%">
		                <tbody><tr height="50px"><td width="100%">
        						<div class="logo" style="font-size:30px; color:#fff; float:left;"><a href="brijeshyadav.ml" style="text-decoration: none !important; color: inherit;">Brijesh Yadav</a></div>
		                </td></tr></tbody>
		        </table>
			</td></tr>
			<tr><td style="padding:10px;">
			    <div style="font-family: Verdana, Geneva, sans-serif;">
			    <div style="color: #006; font-size: 22px; "><strong>Contact - Brijesh Yadav.</strong></div>
			    <div style="font-size: 12px">
			    <p>Hello '.$name.',</p>
			    <p><strong>Thanks for reaching out to me .</p>
			    <p><span style="font-family: "Open Sans", sans-serif; font-size: 14px; line-height: 20px;">You send the following message : '.$message.'</span></p>
			    <p><span style="font-family: "Open Sans", sans-serif; font-size: 14px; line-height: 20px;">In case of any queries or urgency, you can reach me at my Mobile No : 8734819338</span></p>

			    <p>Regards,</p>
			    Brijesh Yadav</div>
			    </div>
			</td></tr>
			<tr><td>
			<table bgcolor="#212121" border="0" cellpadding="0" cellspacing="0" style="padding:10px;" width="100%">
				<tbody><tr>
						<td style="text-align:center">
						<div style="font-size:15px; color:#fff; padding:8px 0;">Copyright &copy; Brijesh Yadav, All Rights Reserved.</div>
						</td></tr>
				</tbody></table>
			    </td></tr></tbody>
            </table>';
	$mail->IsHTML(true);
	$mail->Username = 'brijeshyadav152@gmail.com';
	$mail->Password = 'nameisnameis';
	//$mail->SetFrom(SMTP_USERNAME);
	$mail->SetFrom($from_email, $from_nm);
	$mail->AddReplyTo($from_email, $from_nm);
	$mail->Subject = 'Contact - Brijesh Yadav';
	$mail->Body = $mailbody;
	$mail->AddAddress($email);

	$result = true;
		if (!$mail->Send()) {
			//echo "Mailer Error: " . $mail->ErrorInfo;
			$result = false;
		}
		else
		{
		    $from_nm = 'Brijesh Yadav';
	        $from_email = 'brijeshyadav152@gmail.com';

        	$headers = "Reply-To: Brijesh Yadav <admin@brijeshyadav.ml>\r\n";
        	$headers .= "From: Brijesh Yadav <admin@brijeshyadav.ml>\r\n";
        	$headers .= "Return-Path: Brijesh Yadav <admin@brijeshyadav.ml>\r\n";
        	$headers .= "Organization: Brijesh Yadav\r\n";
        	$headers .= "X-Priority: 3\r\n";
        	$headers .= "X-Mailer: PHP" . phpversion() . "\r\n";
        	$headers .= "MIME-Version: 1.0\r\n";
        	$headers .= "Content-Transfer-Encoding: 8bit\r\n";
        	$headers .= "Content-type: text/html; charset=UTF-8\r\n";
	
        	$mail = new PHPMailer(); // create a new object
        	$mail->IsSMTP(); // enable SMTP
        	$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
        	$mail->SMTPAuth = true; // authentication enabled
        	//mail via gmail
        	$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
        	$mail->Host = "smtp.gmail.com";
        	$mail->Port = 465; // or 587

            $mailbody = '<table bgcolor="#ececec" border="0" cellpadding="0" cellspacing="0" style="margin:0 auto 0;" width="90%">
        	                <tbody><tr><td><table bgcolor="#b62c29" border="0" cellpadding="0" cellspacing="0" style="padding:10px;" width="100%">
        		                <tbody><tr height="50px"><td width="100%">
                						<div class="logo" style="font-size:30px; color:#fff; float:left;"><a href="brijeshyadav.ml" style="text-decoration: none !important; color: inherit;">Brijesh Yadav</a></div>
        		                </td></tr></tbody>
        		        </table>
        			</td></tr>
        			<tr><td style="padding:10px;">
        			    <div style="font-family: Verdana, Geneva, sans-serif;">
        			    <div style="color: #006; font-size: 22px; "><strong>Contact - Brijesh Yadav.</strong></div>
        			    <div style="font-size: 12px">
        			    <p><strong>You have new message on our website from '.$name.'.</p>
        			    <p><strong>Location '.$location.'.</p>
        			    <p><strong>IP address '.$ip.'.</p>
        			    <p><span style="font-family: "Open Sans", sans-serif; font-size: 14px; line-height: 20px;">You have recieved the following message : '.$message.'</span></p>
        
        			    <p>Regards,</p>
        			    '.$name.'</div>
        			    </div>
        			</td></tr>
        			<tr><td>
        			<table bgcolor="#212121" border="0" cellpadding="0" cellspacing="0" style="padding:10px;" width="100%">
        				<tbody><tr>
        						<td style="text-align:center">
        						<div style="font-size:15px; color:#fff; padding:8px 0;">Copyright &copy; Brijesh Yadav, All Rights Reserved.</div>
        						</td></tr>
        				</tbody></table>
        			    </td></tr></tbody>
                    </table>';
	$mail->IsHTML(true);
	$mail->Username = 'brijeshyadav152@gmail.com';
	$mail->Password = 'nameisnameis';
	//$mail->SetFrom(SMTP_USERNAME);
	$mail->SetFrom($from_email, $from_nm);
	$mail->AddReplyTo($from_email, $from_nm);
	$mail->Subject = 'Contact - Brijesh Yadav';
	$mail->Body = $mailbody;
	$mail->AddAddress($from_email);
	$mail->Send();
		    header("Location: ../"); /* Redirect browser */

		}

	return $result;
?>