<?php 
        $file = 'error.pdf';
           if(file_exists($file)){
				header('Pragma: public');
				header('Expires: 0');
				header('Cache-Control: must-revalidate, post-check=0, pre-check=0');		
				header('Cache-Control: private', false);
				header('Last-Modified: ' . gmdate('D, d M Y H:i:s',filemtime($file)) . ' GMT');
				header('Content-disposition: attachment; filename='.$file);
				header("Content-Transfer-Encoding:  binary");
				header('Content-Length: ' . filesize($file));
				header('Connection: close');
				readfile($file);
				ob_clean();
                flush();
				exit;
			}
			?>