<!DOCTYPE html>
<html lang="en">
<head>
  <title>Brijesh Yadav</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="HTML5 website template">
  <meta name="keywords" content="portfolio, brijesh, yadav, developer">
  <meta name="author" content="Brijesh Yadav">
  <link rel="stylesheet" href="../assets/css/main.css">
</head>
<body>

<!-- notification for small viewports and landscape oriented smartphones -->
<div class="device-notification">
  <a class="device-notification--logo" href="#0">
    <img src="../warn.png" alt="Global" width="100px" height="100px">
  </a>
  <p class="device-notification--message">Sorry, this resolution is not support.This webpage has so much to offer that it's a request to you orient your device to portrait or find a larger screen. You won't be disappointed.</p>
</div>

<div class="perspective effect-rotate-left">
  <div class="container"><div class="outer-nav--return"></div>
    <div id="viewport" class="l-viewport">
      <div class="l-wrapper">
        <header class="header">
        </header>
        <ul class="l-main-content">
          <li class="l-section section section--is-active">
            <div class="intro">
              <div class="intro--banner"> 
                <button class="" onclick="window.location.href= '../'"">Go to Home
                  <span class="btn-background"></span>
                </button>
                <br>
                <div class="intro--options">
                  <h3> Organization Name : </h3>              
                </div>
                <div class="intro--options">
                  <p>Ncrypted Technologies Pvt. Ltd </p>             
                </div>
                <div class="intro--options">
                  <h3> Desgination : </h3>              
                </div>
                <div class="intro--options">
                  <p>Web Developer</p>             
                </div>
                <img src="../assets/img/avatar1.png" alt="Welcome" width="450">
              </div>
            </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="../assets/js/vendor/jquery-2.2.4.min.js"><\/script>')</script>
<script src="../assets/js/functions-min.js"></script>
</body>
</html>