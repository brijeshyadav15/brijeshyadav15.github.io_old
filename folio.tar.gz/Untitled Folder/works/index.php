<link rel="stylesheet" href="style.css">
<a href="../"><img src="../code.png" alt="Global" width="50px" height="50px"></a>
<head>
    <title>MOOCS</title>
</head>
<center><h1 style="color:white;margin-top:-50px;">MOOCS</h1></center>
<ul class="cards">
  <li class="card">
    <div class="card__inner" id="card_3">
      <h2></h2>
      <div class="card__buttons">
        <a>Stock value</a>
        <a>Predictor</a>
      </div>
    </div>
    <h3 class="card__tagline">SVP</h3>
    <i class="fa fa-coffee">Domains</i>
    <ul class="card__icons">
      <li><i class="fa fa-coffee">Machine Learning</i></li>
      <li><i class="fa fa-bolt">Data Scrapping</i></li>
      <li><i class="fa fa-bomb">Data Manipulation</i></li>
      <li><i class="fa fa-cutlery">Artificial Intelligence</i></li>
    </ul>
  </li>
  <li class="card">
    <div class="card__inner" id="card_4">
      <h2></h2>
      <div class="card__buttons">
        <a>Virtual</a>
        <a>Mouse</a>
      </div>
    </div>
    <h3 class="card__tagline">Virtual Mouse</h3>
    <i class="fa fa-coffee">Domains</i>
    <ul class="card__icons">
      <li><i class="fa fa-coffee">Java</i></li>
      <li><i class="fa fa-bolt">Computer Vision</i></li>
      <li><i class="fa fa-bomb">OpenCV</i></li>
      <li><i class="fa fa-bomb">JavaCV</i></li>
    </ul>
  </li>
  <li class="card">
    <div class="card__inner" id="card_1">
      <h2></h2>
      <!-- <div class="card__buttons">
        <a href="https://www.datacamp.com/courses/intro-to-python-for-data-science" target="_blank">View</a>
        <a href="https://www.datacamp.com/statement-of-accomplishment/course/0bc5eead7c4be93ef516e6d996f2ce4b9aa25431" target="_blank">Verify</a>
      </div> -->
    </div>
    <h3 class="card__tagline">IP-PBX</h3>
    <i class="fa fa-coffee">Domains</i>
    <ul class="card__icons">
      <li><i class="fa fa-coffee">Networking</i></li>
      <li><i class="fa fa-bolt">LAN configuration</i></li>
      <li><i class="fa fa-cutlery">Scikit Learn</i></li>
    </ul>
  </li>
</ul>