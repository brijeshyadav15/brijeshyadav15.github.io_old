<link rel="stylesheet" href="style.css">
<a href="../"><img src="../code.png" alt="Global" width="50px" height="50px"></a>
<head>
    <title>MOOCS</title>
</head>
<center><h1 style="color:white;margin-top:-50px;">MOOCS</h1></center>
<ul class="cards">
  <li class="card">
    <div class="card__inner" id="card_3">
      <h2></h2>
      <div class="card__buttons">
        <a href="https://courses.edx.org/courses/course-v1:IEEEx+CloudIntro.x+2015T2/course/" target="_blank">View</a>
        <a href="https://s3.amazonaws.com/verify.edx.org/downloads/3b0ce72b484d42b3907db172ce6ce63b/Certificate.pdf" target="_blank">Verify</a>
      </div>
    </div>
    <h3 class="card__tagline">Introductory course for Cloud Computing by IEEE</h3>
    <i class="fa fa-coffee">Skills</i>
    <ul class="card__icons">
      <li><i class="fa fa-coffee">Cloud Computing</i></li>
      <li><i class="fa fa-bolt">PasS</i></li>
      <li><i class="fa fa-bomb">SaaS</i></li>
      <li><i class="fa fa-cutlery">IaaS</i></li>
    </ul>
    <i>Completed</i>
  </li>
  <li class="card">
    <div class="card__inner" id="card_4">
      <h2></h2>
      <div class="card__buttons">
        <a href="https://in.udacity.com/course/intro-to-machine-learning--ud120" target="_blank">View</a>
        <a href="https://s3.amazonaws.com/verify.edx.org/downloads/3b0ce72b484d42b3907db172ce6ce63b/Certificate.pdf" target="_blank">Verify</a>
      </div>
    </div>
    <h3 class="card__tagline">Introductory course for Machine Learning by Udacity</h3>
    <i class="fa fa-coffee">Skills</i>
    <ul class="card__icons">
      <li><i class="fa fa-coffee">Artificial Intellligence</i></li>
      <li><i class="fa fa-bolt">Machine Learning</i></li>
      <li><i class="fa fa-bomb">Reinforcement Learning</i></li>
    </ul>
    <i>Completed</i>
  </li>
  <li class="card">
    <div class="card__inner" id="card_1">
      <h2></h2>
      <div class="card__buttons">
        <a href="https://www.datacamp.com/courses/intro-to-python-for-data-science" target="_blank">View</a>
        <a href="https://www.datacamp.com/statement-of-accomplishment/course/0bc5eead7c4be93ef516e6d996f2ce4b9aa25431" target="_blank">Verify</a>
      </div>
    </div>
    <h3 class="card__tagline">Python basics for Data Science and introduction to numpy and Scikit Learn</h3>
    <i class="fa fa-coffee">Skills</i>
    <ul class="card__icons">
      <li><i class="fa fa-coffee">Python</i></li>
      <li><i class="fa fa-bolt">Data Science</i></li>
      <li><i class="fa fa-bomb">Numpy</i></li>
      <li><i class="fa fa-cutlery">Scikit Learn</i></li>
    </ul>
    <i>Completed</i>
  </li>
  <li class="card">
    <div class="card__inner" id="card_2">
      <h2></h2>
      <div class="card__buttons">
        <a href="https://www.datacamp.com/courses/intro-to-sql-for-data-science">View</a>
        <a href="https://www.datacamp.com/statement-of-accomplishment/course/24ac6d5ca20198f77aad533814335bde7747cf50">Verify</a>
      </div>
    </div>
    <h3 class="card__tagline">SQL operations for basic Data Operations and manipulation</h3>
    <i class="fa fa-coffee">Skills</i>
    <ul class="card__icons">
      <li><i class="fa fa-coffee">SQL</i></li>
      <li><i class="fa fa-bolt">JOINS</i></li>
      <li><i class="fa fa-bomb">Data-Mining</i></li>
      <li><i class="fa fa-cutlery">Data Extraction</i></li>
    </ul>
    <i>Completed</i>
  </li>
</ul>