<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="style.css">
<head>
    <title>SKILLS</title>
</head>
    <a class="header--logo" href="../">
            <img src="../code.png" alt="Home Logo" width="50px" height="50px">
    </a>
        <center><h1 style="color:white; margin-top:-50px;">SKILLS</h1></center>
        <div class="col-md-2 col-sm-2">
        </div>
      <div class="bs-callout-danger col-md-8 col-sm-8">
        <h2 style="color:red">Language and Platform Skills</h2>
        <ul class="list-group">
          <a class="list-group-item inactive-link" href="#" style="background-color:black;">
            <div class="progress">
              <div data-placement="top" style="width: 80%;" 
              aria-valuemax="100" aria-valuemin="0" aria-valuenow="80" role="progressbar" class="progress-bar progress-bar-success">
                <span class="sr-only">60%</span>
                <span class="progress-type">Java/ JavaEE/ Spring Framework </span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 70%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="1" role="progressbar" class="progress-bar progress-bar-success">
                <span class="sr-only">80%</span>
                <span class="progress-type">PHP/ Lamp Stack</span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 70%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="1" role="progressbar" class="progress-bar progress-bar-success">
                <span class="sr-only">70%</span>
                <span class="progress-type">JavaScript/ MEAN stack </span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 65%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="1" role="progressbar" class="progress-bar progress-bar-warning">
                <span class="sr-only">75%</span>
                <span class="progress-type">Python/ Numpy/ Scipy</span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 60%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="60" role="progressbar" class="progress-bar progress-bar-warning">
                <span class="sr-only">60%</span>
                <span class="progress-type">C</span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 50%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="50" role="progressbar" class="progress-bar progress-bar-warning">
                <span class="sr-only">50%</span>
                <span class="progress-type">C++</span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 50%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="50" role="progressbar" class="progress-bar progress-bar-warning">
                <span class="sr-only">50%</span>
                <span class="progress-type">Tensorflow / Pandas / Scikit Learn</span>
              </div>
            </div>
            <div class="progress">
              <div data-placement="top" style="width: 10%;" aria-valuemax="100" aria-valuemin="0" aria-valuenow="50" role="progressbar" class="progress-bar progress-bar-danger">
                <span class="sr-only">10%</span>
                <span class="progress-type">Go</span>
              </div>
            </div>

            <div class="progress-meter">
              <div style="width: 25%;" class="meter meter-left"><span class="meter-text">I suck</span></div>
              <div style="width: 25%;" class="meter meter-left"><span class="meter-text">I know little</span></div>
              <div style="width: 30%;" class="meter meter-right"><span class="meter-text">I'm a guru</span></div>
              <div style="width: 20%;" class="meter meter-right"><span class="meter-text">I''m good</span></div>
            </div>
          </a>
        </ul>
      </div>
        
        <!--<link rel="stylesheet" href="../assets/css/main.css">-->
        <!--    <div class="work-request--options bs-callout-danger col-md-10">-->
        <!--        <h2 style="color:red">Domains</h2>-->
        <!--          <span class="options-a">-->
        <!--            <input id="opt-1" type="checkbox" value="app design">-->
        <!--            <label for="opt-1">-->
        <!--              <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"-->
        <!--              viewBox="0 0 150 111" style="enable-background:new 0 0 150 111;" xml:space="preserve">-->
        <!--              <g transform="translate(0.000000,111.000000) scale(0.100000,-0.100000)">-->
        <!--                <path d="M950,705L555,310L360,505C253,612,160,700,155,700c-6,0-44-34-85-75l-75-75l278-278L550-5l475,475c261,261,475,480,475,485c0,13-132,145-145,145C1349,1100,1167,922,950,705z"/>-->
        <!--              </g>-->
        <!--              </svg>-->
        <!--              App Design-->
        <!--            </label>-->
        <!--            <input id="opt-2" type="checkbox" value="graphic design">-->
        <!--            <label for="opt-2">-->
        <!--              <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"-->
        <!--              viewBox="0 0 150 111" style="enable-background:new 0 0 150 111;" xml:space="preserve">-->
        <!--              <g transform="translate(0.000000,111.000000) scale(0.100000,-0.100000)">-->
        <!--                <path d="M950,705L555,310L360,505C253,612,160,700,155,700c-6,0-44-34-85-75l-75-75l278-278L550-5l475,475c261,261,475,480,475,485c0,13-132,145-145,145C1349,1100,1167,922,950,705z"/>-->
        <!--              </g>-->
        <!--              </svg>-->
        <!--              Graphic Design-->
        <!--            </label>-->
        <!--            <input id="opt-3" type="checkbox" value="motion design">-->
        <!--            <label for="opt-3">-->
        <!--              <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"-->
        <!--              viewBox="0 0 150 111" style="enable-background:new 0 0 150 111;" xml:space="preserve">-->
        <!--              <g transform="translate(0.000000,111.000000) scale(0.100000,-0.100000)">-->
        <!--                <path d="M950,705L555,310L360,505C253,612,160,700,155,700c-6,0-44-34-85-75l-75-75l278-278L550-5l475,475c261,261,475,480,475,485c0,13-132,145-145,145C1349,1100,1167,922,950,705z"/>-->
        <!--              </g>-->
        <!--              </svg>-->
        <!--              Motion Design-->
        <!--            </label>-->
        <!--          </span>-->
        <!--          <span class="options-b">-->
        <!--            <input id="opt-4" type="checkbox" value="ux design">-->
        <!--            <label for="opt-4">-->
        <!--              <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"-->
        <!--              viewBox="0 0 150 111" style="enable-background:new 0 0 150 111;" xml:space="preserve">-->
        <!--              <g transform="translate(0.000000,111.000000) scale(0.100000,-0.100000)">-->
        <!--                <path d="M950,705L555,310L360,505C253,612,160,700,155,700c-6,0-44-34-85-75l-75-75l278-278L550-5l475,475c261,261,475,480,475,485c0,13-132,145-145,145C1349,1100,1167,922,950,705z"/>-->
        <!--              </g>-->
        <!--              </svg>-->
        <!--              UX Design-->
        <!--            </label>-->
        <!--            <input id="opt-5" type="checkbox" value="webdesign">-->
        <!--            <label for="opt-5">-->
        <!--              <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"-->
        <!--              viewBox="0 0 150 111" style="enable-background:new 0 0 150 111;" xml:space="preserve">-->
        <!--              <g transform="translate(0.000000,111.000000) scale(0.100000,-0.100000)">-->
        <!--                <path d="M950,705L555,310L360,505C253,612,160,700,155,700c-6,0-44-34-85-75l-75-75l278-278L550-5l475,475c261,261,475,480,475,485c0,13-132,145-145,145C1349,1100,1167,922,950,705z"/>-->
        <!--              </g>-->
        <!--              </svg>-->
        <!--              Webdesign-->
        <!--            </label>-->
        <!--            <input id="opt-6" type="checkbox" value="marketing">-->
        <!--            <label for="opt-6">-->
        <!--              <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"-->
        <!--              viewBox="0 0 150 111" style="enable-background:new 0 0 150 111;" xml:space="preserve">-->
        <!--              <g transform="translate(0.000000,111.000000) scale(0.100000,-0.100000)">-->
        <!--                <path d="M950,705L555,310L360,505C253,612,160,700,155,700c-6,0-44-34-85-75l-75-75l278-278L550-5l475,475c261,261,475,480,475,485c0,13-132,145-145,145C1349,1100,1167,922,950,705z"/>-->
        <!--              </g>-->
        <!--              </svg>-->
        <!--              Marketing-->
        <!--            </label>-->
        <!--            </span>-->
        <!--        </div>-->